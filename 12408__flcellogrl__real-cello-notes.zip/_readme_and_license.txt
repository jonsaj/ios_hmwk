Sound pack downloaded from Freesound.org
----------------------------------------

This pack of sounds contains sounds by flcellogrl ( http://www.freesound.org/people/flcellogrl/  )
You can find this pack online at: http://www.freesound.org/people/flcellogrl/packs/12408/


License details
---------------

Sampling+: http://creativecommons.org/licenses/sampling+/1.0/
Creative Commons 0: http://creativecommons.org/publicdomain/zero/1.0/
Attribution: http://creativecommons.org/licenses/by/3.0/
Attribution Noncommercial: http://creativecommons.org/licenses/by-nc/3.0/


Sounds in this pack
-------------------

  * 195702__flcellogrl__9-cello-g-4-ab4.wav
    * url: http://www.freesound.org/people/flcellogrl/sounds/195702/
    * license: Attribution
  * 195701__flcellogrl__7-cello-f-4-gb4.wav
    * url: http://www.freesound.org/people/flcellogrl/sounds/195701/
    * license: Attribution
  * 195700__flcellogrl__8-cello-g4.wav
    * url: http://www.freesound.org/people/flcellogrl/sounds/195700/
    * license: Attribution
  * 195699__flcellogrl__5-cello-e4.wav
    * url: http://www.freesound.org/people/flcellogrl/sounds/195699/
    * license: Attribution
  * 195698__flcellogrl__6-cello-f4.wav
    * url: http://www.freesound.org/people/flcellogrl/sounds/195698/
    * license: Attribution
  * 195697__flcellogrl__1-cello-c5.wav
    * url: http://www.freesound.org/people/flcellogrl/sounds/195697/
    * license: Attribution
  * 195696__flcellogrl__2-cello-c-4-db4.wav
    * url: http://www.freesound.org/people/flcellogrl/sounds/195696/
    * license: Attribution
  * 195695__flcellogrl__3-cello-d4.wav
    * url: http://www.freesound.org/people/flcellogrl/sounds/195695/
    * license: Attribution
  * 195694__flcellogrl__4-cello-d-4-eb4.wav
    * url: http://www.freesound.org/people/flcellogrl/sounds/195694/
    * license: Attribution
  * 195693__flcellogrl__10-cello-a4.wav
    * url: http://www.freesound.org/people/flcellogrl/sounds/195693/
    * license: Attribution
  * 195692__flcellogrl__11-cello-a-4-bb4.wav
    * url: http://www.freesound.org/people/flcellogrl/sounds/195692/
    * license: Attribution
  * 195691__flcellogrl__12-cello-b4.wav
    * url: http://www.freesound.org/people/flcellogrl/sounds/195691/
    * license: Attribution
  * 195690__flcellogrl__1-cello-c4.wav
    * url: http://www.freesound.org/people/flcellogrl/sounds/195690/
    * license: Attribution
  * 195689__flcellogrl__10-cello-a3-openstring.wav
    * url: http://www.freesound.org/people/flcellogrl/sounds/195689/
    * license: Attribution
  * 195688__flcellogrl__12-cello-b3.wav
    * url: http://www.freesound.org/people/flcellogrl/sounds/195688/
    * license: Attribution
  * 195552__flcellogrl__9-cello-g-3-ab3.wav
    * url: http://www.freesound.org/people/flcellogrl/sounds/195552/
    * license: Attribution
  * 195551__flcellogrl__7-cello-f-3-gb3.wav
    * url: http://www.freesound.org/people/flcellogrl/sounds/195551/
    * license: Attribution
  * 195550__flcellogrl__8-cello-g3-2notes.wav
    * url: http://www.freesound.org/people/flcellogrl/sounds/195550/
    * license: Attribution
  * 195549__flcellogrl__3-cello-d3-openstring.wav
    * url: http://www.freesound.org/people/flcellogrl/sounds/195549/
    * license: Attribution
  * 195548__flcellogrl__4-cello-d-3-eb3.wav
    * url: http://www.freesound.org/people/flcellogrl/sounds/195548/
    * license: Attribution
  * 195547__flcellogrl__5-cello-e3.wav
    * url: http://www.freesound.org/people/flcellogrl/sounds/195547/
    * license: Attribution
  * 195546__flcellogrl__6-cello-f3.wav
    * url: http://www.freesound.org/people/flcellogrl/sounds/195546/
    * license: Attribution
  * 195545__flcellogrl__10-cello-a3-fingeredondstring.wav
    * url: http://www.freesound.org/people/flcellogrl/sounds/195545/
    * license: Attribution
  * 195544__flcellogrl__11-cello-a-3-bb3.wav
    * url: http://www.freesound.org/people/flcellogrl/sounds/195544/
    * license: Attribution
  * 195543__flcellogrl__2-cello-c-3-db3.wav
    * url: http://www.freesound.org/people/flcellogrl/sounds/195543/
    * license: Attribution
  * 195542__flcellogrl__3-cello-d3-fingerongstring.wav
    * url: http://www.freesound.org/people/flcellogrl/sounds/195542/
    * license: Attribution
  * 195285__flcellogrl__9-cello-g-2-ab2.wav
    * url: http://www.freesound.org/people/flcellogrl/sounds/195285/
    * license: Attribution
  * 195284__flcellogrl__8-cello-g2-openstring.wav
    * url: http://www.freesound.org/people/flcellogrl/sounds/195284/
    * license: Attribution
  * 195283__flcellogrl__7-cello-f-2-gb2.wav
    * url: http://www.freesound.org/people/flcellogrl/sounds/195283/
    * license: Attribution
  * 195282__flcellogrl__8-cello-g2-fingeroncstring.wav
    * url: http://www.freesound.org/people/flcellogrl/sounds/195282/
    * license: Attribution
  * 195281__flcellogrl__5-cello-e2.wav
    * url: http://www.freesound.org/people/flcellogrl/sounds/195281/
    * license: Attribution
  * 195280__flcellogrl__6-cello-f2.wav
    * url: http://www.freesound.org/people/flcellogrl/sounds/195280/
    * license: Attribution
  * 195279__flcellogrl__1-cello-c3.wav
    * url: http://www.freesound.org/people/flcellogrl/sounds/195279/
    * license: Attribution
  * 195278__flcellogrl__2-cello-c-2-db2.wav
    * url: http://www.freesound.org/people/flcellogrl/sounds/195278/
    * license: Attribution
  * 195277__flcellogrl__3-cello-d2.wav
    * url: http://www.freesound.org/people/flcellogrl/sounds/195277/
    * license: Attribution
  * 195276__flcellogrl__4-cello-d-2-eb2.wav
    * url: http://www.freesound.org/people/flcellogrl/sounds/195276/
    * license: Attribution
  * 195275__flcellogrl__10-cello-a2.wav
    * url: http://www.freesound.org/people/flcellogrl/sounds/195275/
    * license: Attribution
  * 195274__flcellogrl__11-cello-a-2-bb2.wav
    * url: http://www.freesound.org/people/flcellogrl/sounds/195274/
    * license: Attribution
  * 195273__flcellogrl__12-cello-b2.wav
    * url: http://www.freesound.org/people/flcellogrl/sounds/195273/
    * license: Attribution
  * 195272__flcellogrl__1-cello-c2.wav
    * url: http://www.freesound.org/people/flcellogrl/sounds/195272/
    * license: Attribution

